

## load the package
# install.packages("run_aCRFExtractor", ...)
# library(run_aCRFExtractor.R)

source("./functions/aCRFExtractor_mainFn.R")

## run the run_aCRF_minner application
run_aCRFExtractor()
