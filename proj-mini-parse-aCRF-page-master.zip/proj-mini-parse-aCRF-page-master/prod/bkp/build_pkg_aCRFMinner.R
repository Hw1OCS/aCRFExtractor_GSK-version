


# devtools::install_github("hadley/devtools")
library(devtools)

## add description file
# load_all()             ## not working, instead create pkg via Rstudio project
# load_all("./")

## once you creted the package via Rstudio project setup
## -- 1. modify DESCRIPTION file
## -- 2. To verify DESCRIPTION file, run <load_all()>
## -- you should see a message <Loading aCRFMinner>

## documentation
library(roxygen2)
roxygenise(package.dir = "./")
