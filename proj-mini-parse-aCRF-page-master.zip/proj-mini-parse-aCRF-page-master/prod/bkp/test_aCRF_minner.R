
## load main source file
source("./functions/run_aCRF_minner_mainFn.R")

## define input files
# inputFiles_dir <- ""

# studyid <- "115649"
# aCRF <- paste(inputFiles_dir, "/", "blankcrf.pdf", sep = "")
# defOrig <- paste("./", "115649_DEFINE_ORIGIN.xlsx", sep = "")

# aCRF_file <- "/Users/workuhm/Desktop/aCRF_files/115649/blankcrf.pdf"
# defOrig_file <- "/Users/workuhm/Desktop/aCRF_files/115649/115649_DEFINE_ORIGIN.xlsx"
# defOrig_sheet <- "Variable"
# 
# pgs_aCRF_out <- aCRF_minner(studyid = studyid, 
#                             aCRF_fileName = aCRF_file, 
#                             defOrig_fileName = defOrig_file, defOrig_sheetName = defOrig_sheet)

# pgs_aCRF_out <- aCRF_minner()
run_aCRF_minner()

## -- Export updated Define Origin file
# output_dir <- "/Users/workuhm/Desktop/aCRF_files/115649/"
# output_dir <- "/Users/workuhm/Desktop/aCRF_files/115649"
# fileOut_name <- paste(output_dir, "defineOrigin_variableTab_pageNumbers_", studyid, "_", 
#                       str_replace_all(format(Sys.time(), "%b %d %Y"), " ", "_"), 
#                       ".xls", sep = "")
# fileOut_name <- paste("defineOrigin_variableTab_pageNumbers_", studyid, "_", 
#                       str_replace_all(format(Sys.time(), "%b %d %Y"), " ", "_"), 
#                       ".xls", sep = "")

# sheetout_name <- paste("defineOrigin_variableTab_pageNumbers", studyid, sep = "")



# write.xlsx(x = pgs_aCRF_out, file = fileout_name, sheetName = sheetout_name,
#            row.names = FALSE, col.names = TRUE)

# write_excel_csv(x = pgs_aCRF_out, path = fileOut_name, col_names = T)
# write_csv(x = pgs_aCRF_out, path = file.path(output_dir, fileOut_name), col_names = T)     ## powered by pkg::readr
# write.table(x = pgs_aCRF_out, file = file.path(output_dir, fileOut_name), row.names = F, col.names = T)



